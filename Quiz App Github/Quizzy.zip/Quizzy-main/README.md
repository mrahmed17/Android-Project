UserName: 'user'
Password: 'password'
if still doesn't work try to look into mainActivity.java file its stroed there for reference 
Thanks
